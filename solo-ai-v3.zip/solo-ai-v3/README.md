# SOLO AI v3 — Multi-Model Intelligence Platform

Premium AI assistant with proper per-provider routing for 17 models across 6 providers.

---

## Quick Start

```bash
git clone <your-repo>
cd solo-ai-v3
npm install
cp .env.example .env
# Fill in VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY
npm run dev
```

---

## Architecture

```
src/
├── App.tsx                   # Root — auth gate + layout
├── main.tsx                  # Entry point
├── index.css                 # CSS variables + animations
├── types.ts                  # All TypeScript interfaces + model data
├── vite-env.d.ts             # Env types + Web Speech API
├── lib/
│   ├── supabase.ts           # Supabase client
│   ├── settings.ts           # LocalStorage settings persistence
│   ├── tts.ts                # Text-to-speech helper
│   └── files.ts              # File processing (images, PDFs, text)
├── hooks/
│   ├── useAuth.ts            # Auth state + signIn/signUp/signOut
│   ├── useChat.ts            # Conversations + streaming + DB
│   └── useSettings.ts       # Settings state + theme application
└── components/
    ├── AuthScreen.tsx        # Email/password auth UI
    ├── Sidebar.tsx           # Conversation list + search + pin/rename/delete
    ├── ChatMessage.tsx       # Markdown render + code blocks + actions
    ├── ChatInput.tsx         # Textarea + file upload + voice input
    ├── ModelSelector.tsx     # Model picker dropdown
    ├── WelcomeScreen.tsx     # Landing with suggestions
    └── SettingsModal.tsx     # Theme/accent/API keys/advanced settings

supabase/
├── functions/chat/index.ts   # Edge Function — routes to 6 AI providers
└── migrations/
    └── 20260517000001_v3_upgrade.sql
```

---

## Supabase Setup

### 1. Create project at supabase.com

### 2. Run migration
Go to SQL Editor and run contents of `supabase/migrations/20260517000001_v3_upgrade.sql`

### 3. Deploy Edge Function
```bash
npm install -g supabase
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase functions deploy chat
```

### 4. Set Edge Function Secrets
In Supabase Dashboard → Edge Functions → chat → Secrets:
```
GROQ_API_KEY=gsk_...         # Free at console.groq.com
GOOGLE_API_KEY=AIza...       # Free at aistudio.google.com
OPENAI_API_KEY=sk-...        # platform.openai.com (optional)
ANTHROPIC_API_KEY=sk-ant-... # console.anthropic.com (optional)
DEEPSEEK_API_KEY=sk-...      # platform.deepseek.com (optional)
```

**Minimum required:** Only `GROQ_API_KEY` needed for free tier (Llama 3.3 70B).
Adding Gemini key adds free Gemini 2.0 Flash. Everything else is optional.

---

## AI Models (17 total)

| Model | Provider | Free | Category |
|-------|----------|------|----------|
| GPT-4o | OpenAI | ✗ | Conversation |
| GPT-4o Mini | OpenAI | ✗ | Fast |
| GPT-4 Turbo | OpenAI | ✗ | Coding |
| Claude 3.7 Sonnet | Anthropic | ✗ | Coding |
| Claude 3.5 Haiku | Anthropic | ✗ | Fast |
| Claude 3 Opus | Anthropic | ✗ | Research |
| Gemini 2.0 Flash | Google | ✓ | Research |
| Gemini 1.5 Pro | Google | ✗ | Research |
| Llama 3.3 70B | Groq | ✓ | Free |
| Llama 3.1 8B | Groq | ✓ | Fast |
| Mistral Small | Groq | ✓ | Fast |
| Gemma 3 27B | Groq | ✓ | Fast |
| Qwen 2.5 72B | Groq | ✓ | Reasoning |
| Phi-4 Reasoning | Groq | ✓ | Reasoning |
| R1 Chimera | Groq | ✓ | Reasoning |
| DeepSeek R1 | DeepSeek | ✗ | Reasoning |
| DeepSeek V3 | DeepSeek | ✗ | Coding |

### Auto-routing Logic
The backend scores the last user message with keyword weights:
- **Coding** → Claude 3.7 Sonnet (code, debug, function, typescript...)
- **Reasoning** → DeepSeek R1 (explain, analyze, math, logic...)
- **Research** → Gemini 2.0 Flash (research, latest, news, facts...)
- **Fast** → Llama 3.3 70B (quick, short, translate...)
- **Default** → Llama 3.3 70B

---

## Features

### Chat
- ✅ Streaming responses (SSE)
- ✅ Markdown + syntax-highlighted code blocks
- ✅ Copy/read-aloud/regenerate per message
- ✅ Stop generation mid-stream
- ✅ Auto conversation titles
- ✅ Pin / rename / delete conversations
- ✅ Search conversation history

### Models
- ✅ 17 models across 6 providers
- ✅ Each provider uses its own correct API
- ✅ Auto-routing based on query type
- ✅ Fallback chain on API failure
- ✅ Per-model speed/quality indicators
- ✅ Client-side API key override

### Files & Voice
- ✅ Image upload (JPEG/PNG/GIF/WebP)
- ✅ Text/CSV file upload with extraction
- ✅ Drag-and-drop support
- ✅ Voice input (Web Speech API)
- ✅ Text-to-speech output

### UI
- ✅ Dark/light/system theme
- ✅ 6 accent color options
- ✅ Glassmorphism cards
- ✅ Smooth animations throughout
- ✅ Mobile-responsive sidebar
- ✅ Typing/streaming indicators
- ✅ Scroll-to-bottom button
- ✅ Settings modal

---

## Deployment

### Netlify / Vercel (Recommended)

```bash
npm run build
# Deploy /dist folder
```

Set environment variables in dashboard:
```
VITE_SUPABASE_URL=...
VITE_SUPABASE_ANON_KEY=...
```

### Docker

```dockerfile
FROM node:20-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=builder /app/dist /usr/share/nginx/html
EXPOSE 80
```

---

## Security Notes

1. **Never expose server-side API keys in frontend** — all AI calls go through Edge Function
2. **RLS is enabled** on all tables — users only see their own data
3. **Client API keys** sent in request body are fine (HTTPS encrypted, not stored)
4. **Rate limiting** — add Supabase Edge Function rate limiting for production
5. **CORS** — Edge Function restricts to configured origins in production

---

## Android APK (Capacitor)

```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "SOLO AI" "com.solo.ai"
npm run build
npx cap add android
npx cap copy android
npx cap open android
# In Android Studio: Build → Generate Signed Bundle/APK
```

---

## Performance

- Code-split: react, supabase, app chunks (~180KB gzipped total)
- Lazy font loading via Google Fonts CSS
- CSS animations use GPU-composited transforms only
- No heavy markdown library — custom lightweight renderer
- Supabase realtime disabled (polling not needed for chat)
